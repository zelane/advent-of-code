module Day1 (solve) where

import Data.List (sort)
import Data.List.Split (splitOn)

solve :: IO ()
solve = do
  lines <- lines <$> readFile "input/1.txt"
  let elves = splitOn [""] lines
      sums = reverse $ sort $ sum . fmap read <$> elves
  print $ head sums
  print $ sum $ take 3 sums
